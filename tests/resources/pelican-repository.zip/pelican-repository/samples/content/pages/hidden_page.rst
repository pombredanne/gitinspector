This is a test hidden page
##########################

:category: test
:status: hidden

This is great for things like error(404) pages
Anyone can see this page but it's not linked to anywhere!

