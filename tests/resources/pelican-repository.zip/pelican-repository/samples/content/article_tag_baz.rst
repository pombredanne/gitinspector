The baz tag
###########

:date: 2010-03-14
:url: tag/baz.html
:save_as: tag/baz.html

This article overrides the listening of the articles under the *baz* tag.
