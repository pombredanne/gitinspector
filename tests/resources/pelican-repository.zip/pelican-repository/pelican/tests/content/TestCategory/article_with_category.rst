This is an article with category !
##################################

:category: yeah
:date: 1970-01-01

This article should be in 'yeah' category.
