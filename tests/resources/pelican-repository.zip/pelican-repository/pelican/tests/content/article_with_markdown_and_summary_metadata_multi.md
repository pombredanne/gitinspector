Title: Article with markdown and summary metadata multi
Date: 2012-10-31
Summary:
    A multi-line summary should be supported
    as well as **inline markup**.
custom_formatted_field:
    Multi-line metadata should also be supported
    as well as *inline markup* and stuff to "typogrify"...

This is some content.
