This is a test hidden page with a custom template
#################################################

:status: hidden
:template: custom

The quick brown fox jumped over the lazy dog's back.

This page is hidden

This page has a custom template to be called when rendered
