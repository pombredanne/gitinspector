This is a test page with a preset template
##########################################

:template: custom

The quick brown fox jumped over the lazy dog's back.

This article has a custom template to be called when rendered
