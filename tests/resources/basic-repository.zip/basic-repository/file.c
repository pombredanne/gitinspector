#include <stdio.h>
#include <math.h>

int fact(int n) {
  if (n<=0)
    return 1;
  else
    return n*fact(n-1);
}

void display_e() {
  printf("%.15f\n", exp(1));
  double res = 0;
  for (int i=0; i<10; i++)
    res += 1.0 / fact(i);
  printf("%.15f\n", res);
}

int main(void) {
  printf("Canular\n");
  display_e();
  return 0;
}
