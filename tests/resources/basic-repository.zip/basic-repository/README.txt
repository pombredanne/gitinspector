Small readme file. But not much to read inside. 
