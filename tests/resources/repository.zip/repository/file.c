#include <stdio.h>

int main(void) {
  printf("Canular\n");
  return 0;
}
