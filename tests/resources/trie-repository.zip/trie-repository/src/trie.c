/*
 * This file is part of the trie library.
 *
 * The trie library is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or at your option) any later version.
 *
 * The trie library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the trie library. If not, see http://www.gnu.org/licenses/.
 */

#include "trie.h"

#include <stdio.h>
#include <stdlib.h>

#include <assert.h>
#include <string.h>

/* Default number of the number of childs in trie node */
#define TRIE_CHILDS         4

/* Private definition of the data-structure */
typedef struct
{
  int symb;
  ssize_t last;
  trie_t *next;
} child_t;

struct trie_t
{
  unsigned int childs_size;
  unsigned int childs_count;
  child_t *childs;
};


/* Allocate a new empty trie */
trie_t *
trie_alloc (void)
{
  /* Allocate trie data-structure */
  trie_t *trie = malloc (sizeof (trie_t));
  if (!trie)
    return NULL;

  /* Allocate child data-structure */
  child_t *child = malloc (TRIE_CHILDS * sizeof (child_t));
  if (!child)
    {
      free (trie);
      return NULL;
    }
  memset (child, 0, TRIE_CHILDS * sizeof (child_t));

  /* Initializing the trie data-structure */
  trie->childs_size = TRIE_CHILDS;
  trie->childs_count = 0;
  trie->childs = child;

  return trie;
}

void
trie_free (trie_t * trie)
{
  if (!trie)
    return;

  for (size_t i = 0; i < trie->childs_count; ++i)
    trie_free (trie->childs[i].next);

  if (trie->childs)
    free (trie->childs);

  free (trie);
}

/* Helper for bsearch and qsort */
static inline int
cmp_childs (const void *k1, const void *k2)
{
  child_t *c1 = (child_t *) k1;
  child_t *c2 = (child_t *) k2;
  return c1->symb - c2->symb;
}

/* Search for a symbol in a childs of a certain trie.
 * Uses binary search as the childs are kept sorted */
static child_t *
trie_search_child (trie_t * trie, int symb)
{
  if (trie->childs_count == 0)
    return NULL;

  child_t s = {.symb = symb };

  return
    (child_t *) bsearch (&s,
			 trie->childs, trie->childs_count,
			 sizeof (child_t), cmp_childs);
}

#define tab(n)                           \
  do {                                   \
       for (int __i = 0; __i < n; ++__i) \
         printf ("  ");                  \
} while (0)

/* Private function to recursively print the trie */
static void
_trie_print_rec (trie_t * t, int level)
{
  if (!t)
    return;

  for (size_t i = 0; i < t->childs_count; i++)
    {
      tab (level);
      printf ("%c %s\n", (char) t->childs[i].symb,
	      t->childs[i].last != TRIE_NOT_LAST ? "[last]" : "");
      _trie_print_rec (t->childs[i].next, level + 1);
    }
}

/* Wrapper for print */
void
trie_print (trie_t * t)
{
  _trie_print_rec (t, 0);
}

/* Add a word to the trie */
void
trie_add_word (trie_t * trie, const char *word, size_t length, ssize_t info)
{
  assert (trie != NULL);

  trie_t *nxt = NULL;
  child_t *child = trie_search_child (trie, word[0]);

  if (child)
    {
      if (length == 1)
	child->last = info;
      if (length > 1 && child->next == NULL)
	child->next = trie_alloc ();

      nxt = child->next;
    }
  else
    {
      if (trie->childs_count >= trie->childs_size)
	{
	  trie->childs_size *= 2;
	  trie->childs = realloc (trie->childs,
				    trie->childs_size * sizeof (child_t));
	}

      trie->childs[trie->childs_count].symb = word[0];
      if (length > 1)
	{
	  trie->childs[trie->childs_count].next = trie_alloc ();
	  trie->childs[trie->childs_count].last = TRIE_NOT_LAST;
	}
      else
	{
	  trie->childs[trie->childs_count].next = NULL;
	  trie->childs[trie->childs_count].last = info;
	}

      nxt = trie->childs[trie->childs_count].next;
      trie->childs_count++;

      qsort (trie->childs, trie->childs_count,
	     sizeof (child_t), cmp_childs);
    }

  if (length > 1)
    trie_add_word (nxt, &word[1], length - 1, info);
}

/* Search for word in trie. Returns true/false */
ssize_t
trie_search (trie_t * trie, const char *word, size_t length)
{
  assert (length > 0);

  if (trie == NULL)
    return TRIE_NOT_LAST;

  child_t *child = trie_search_child (trie, word[0]);

  if (!child)
    return TRIE_NOT_LAST;

  if (length == 1)
    return child->last;
  else
    return trie_search (child->next, &word[1], length - 1);
}

/* Search for a prefix in the trie. Returns a position in the trie. */
trie_t *
trie_check_prefix (trie_t * trie, const char *word, size_t length,
		   ssize_t * last)
{
  assert (length > 0);

  if (trie == NULL)
    goto error;

  child_t *child = trie_search_child (trie, word[0]);

  if (!child)
    goto error;

  if (length == 1)
    {
      *last = child->last;
      return child->next;
    }

  return trie_check_prefix (child->next, &word[1], length - 1, last);

error:
  *last = TRIE_NOT_LAST;
  return NULL;
}
