#ifndef TRIE_H
#define TRIE_H

#include <stddef.h>
#include <sys/types.h>

/* Mark the end of the data-structure */
#define TRIE_NOT_LAST         -1

/* Tries data-structure forward definition */
typedef struct trie_t trie_t;

/* Create a new trie node */
trie_t *trie_alloc (void);

/* Free the memory of the whole trie */
void trie_free (trie_t *);

/* Add a new word in the trie */
void trie_add_word (trie_t *, const char *, size_t, ssize_t);

/* Search the trie for a word */
ssize_t trie_search (trie_t *, const char *, size_t);

/* Search the trie for a given prefix */
trie_t *trie_check_prefix (trie_t *, const char *, size_t, ssize_t *);

/* Display the content of the trie */
void trie_print (trie_t *);

#endif /* TRIE_H */
