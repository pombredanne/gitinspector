/*
 * This file is part of the trie library.
 *
 * The trie library is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or at your option) any later version.
 *
 * The trie library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the trie library. If not, see http://www.gnu.org/licenses/.
 */

#ifndef TRIE_H
#define TRIE_H

#include <stddef.h>
#include <sys/types.h>

/* Mark the end of the data-structure */
#define TRIE_NOT_LAST         -1

/* Tries data-structure forward definition */
typedef struct trie_t trie_t;

/* Create a new trie node */
trie_t *trie_alloc (void);

/* Free the memory of the whole trie */
void trie_free (trie_t *);

/* Add a new word in the trie */
void trie_add_word (trie_t *, const char *, size_t, ssize_t);

/* Search the trie for a word */
ssize_t trie_search (trie_t *, const char *, size_t);

/* Search the trie for a given prefix */
trie_t *trie_check_prefix (trie_t *, const char *, size_t, ssize_t *);

/* Display the content of the trie */
void trie_print (trie_t *);

#endif /* TRIE_H */
