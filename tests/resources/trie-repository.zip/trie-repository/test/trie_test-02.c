#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <libgen.h>
#include <string.h>

#include <trie.h>

/* We want to attach to every word in the trie data-base */
typedef enum
{
  type_a, type_b
} word_type_t;

int
main (int argc, char *argv[])
{
  int ret = EXIT_SUCCESS;
  ssize_t res;

  trie_t *dict = trie_alloc ();
  if (argc <= 1)
    {
      fprintf (stderr, "usage: %s word to find\n", basename (argv[0]));
      exit (EXIT_FAILURE);
    }

  trie_add_word (dict, "hello", strlen ("hello"), (ssize_t) type_a);
  trie_add_word (dict, "hell", strlen ("hell"), (ssize_t) type_b);

  printf ("Printing the trie.\n");
  trie_print (dict);

  res = trie_search (dict, argv[1], strlen (argv[1]));
  printf ("searching '%s' in the database -- %s\n", argv[1],
	  res != TRIE_NOT_LAST ?
	  (word_type_t) res == type_a ? "yes, type A" : "yes, type B" : "no");

  trie_free (dict);
  return ret;
}
