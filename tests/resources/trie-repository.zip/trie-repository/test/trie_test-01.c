/*
 * This file is part of the trie library.
 *
 * The trie library is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or at your option) any later version.
 *
 * The trie library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the trie library. If not, see http://www.gnu.org/licenses/.
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include <assert.h>
#include <string.h>

#include <trie.h>

#define add_word(t, word)  trie_add_word (t, word, strlen (word), 1)

int
main (int argc, char *argv[])
{
  assert (argc > 1);

  /* Intializing the data-base */
  trie_t *t = trie_alloc ();

  add_word (t, "+");
  add_word (t, "++");
  add_word (t, "+=");
  add_word (t, "+++");
  add_word (t, "-+-");
  add_word (t, "+=+");
  add_word (t, "=+=");
  add_word (t, "===");
  add_word (t, "---");
  add_word (t, "+-+");

  printf ("Printing all the database.\n");
  trie_print (t);

  /* Searching the data-base */
  bool check_search = true, check_prefix_search = false;
  if (check_search)
    printf ("searching '%s' in the database -- %s\n",
	    argv[1], trie_search (t, argv[1],
				  strlen (argv[1])) !=
	    TRIE_NOT_LAST ? "yes" : "no");
  else if (check_prefix_search)
    {
      trie_t *res;
      ssize_t last;
      res = trie_check_prefix (t, argv[1], strlen (argv[1]), &last);
      printf ("checking prefix for '%s' in database last: %s, follows:\n",
	      argv[1], last != TRIE_NOT_LAST ? "yes" : "no");
      trie_print (res);
    }

  /* Freeing memory */
  trie_free (t);

  return EXIT_SUCCESS;
}
