#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include <assert.h>
#include <string.h>

#include <trie.h>

#define add_word(t, word)  trie_add_word (t, word, strlen (word), 1)

int
main (int argc, char *argv[])
{
  assert (argc > 1);

  /* Intializing the data-base */
  trie_t *t = trie_alloc ();

  add_word (t, "+");
  add_word (t, "++");
  add_word (t, "+=");
  add_word (t, "+++");
  add_word (t, "-+-");
  add_word (t, "+=+");
  add_word (t, "=+=");
  add_word (t, "===");
  add_word (t, "---");
  add_word (t, "+-+");

  printf ("Printing all the database.\n");
  trie_print (t);

  /* Searching the data-base */
  bool check_search = true, check_prefix_search = false;
  if (check_search)
    printf ("searching '%s' in the database -- %s\n",
	    argv[1], trie_search (t, argv[1],
				  strlen (argv[1])) !=
	    TRIE_NOT_LAST ? "yes" : "no");
  else if (check_prefix_search)
    {
      trie_t *res;
      ssize_t last;
      res = trie_check_prefix (t, argv[1], strlen (argv[1]), &last);
      printf ("checking prefix for '%s' in database last: %s, follows:\n",
	      argv[1], last != TRIE_NOT_LAST ? "yes" : "no");
      trie_print (res);
    }

  /* Freeing memory */
  trie_free (t);

  return EXIT_SUCCESS;
}
